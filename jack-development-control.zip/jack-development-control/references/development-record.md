# JACK Development Record

Use this format for a material diagnosis, implementation, migration, or release. Keep the record proportional to the task while retaining enough evidence to reproduce the decision.

## Event code

Prefer an existing project issue number. If none exists, scan the project's development records and allocate the next unused code:

`JACK-<TYPE>-<YYYYMMDD>-<NNN>`

Types:

- `BUG` defect or regression
- `FEAT` new or changed functionality
- `DB` schema or persistence change
- `PRINT` form, report, preview, or printing change
- `MIG` import, upgrade, backup, or restore change
- `SEC` permissions, audit, licensing, or security change
- `REL` packaging, installer, or release change
- `DOC` manual or specification change

Use the dominant type and cross-reference related codes instead of assigning several codes to the same event. Never invent a sequence number without checking available records; if none are accessible, mark the code `PROVISIONAL`.

## Record template

### Control

| Field | Required content |
|---|---|
| Event code | Unique or provisional code |
| Date | Local project date and timezone if relevant |
| Edition/build | Active JACK edition and version evidence |
| Mode | Review, plan, implement, or release |
| Status | Diagnosed, completed, partially verified, blocked, or released |
| Authorization | The user's instruction that defines the permitted scope |

### Outcome

- **Requested result:** State the user's request without expanding it.
- **Observed behavior:** Record reproducible symptoms and evidence.
- **Verified cause:** Distinguish confirmed cause from inference.
- **Resolution:** Summarize the change or state **No changes made**.

### Impact inventory

| Surface | Exact items | Effect |
|---|---|---|
| Modules | Menus, workflows, reports, or services | User-visible impact |
| Source | File paths and functions/classes/components | Logic impact |
| Data | Tables, columns, indexes, migrations, or stored files | Compatibility and recovery impact |
| Accounting | Journals, ledgers, statements, tax or subsidiary schedules | Reconciliation impact |
| UI/printing | Forms, preview, templates, page layouts | Presentation impact |
| Security | Roles, audit events, licensing, secrets, or network behavior | Control impact |
| Documentation | Manuals, specifications, About screen, or release notes | Documentation impact |

### Code change register

For each meaningful change, record:

| File | Symbol or database object | Before | After | Reason |
|---|---|---|---|---|
| Exact path | Function, class, component, query, table, or migration | Prior behavior | New behavior | Link to cause or acceptance criterion |

Include a focused diff or excerpt only when it helps review the logic. Preserve secrets and private licensing material. Do not paste entire unrelated files.

### Verification

| Test or command | Test data/environment | Expected | Actual | Result |
|---|---|---|---|---|
| Exact command or manual flow | Non-sensitive description | Observable outcome | Observable evidence | Pass, fail, or not run |

Add applicable accounting control totals, record counts, role/permission cases, printed-page checks, migration/restore evidence, and host/client results.

### Release and recovery

- **Version effect:** No change, proposed change, or exact released version with rationale.
- **Compatibility:** Supported prior data/builds and known exclusions.
- **Rollback/recovery:** Exact safe recovery procedure or backup reference.
- **Remaining validation:** Tests not run, reasons, owners, and blockers.
- **Related events:** Cross-referenced JACK codes.
