# JACK Product and Control Invariants

Use only the sections relevant to the change. Confirm the active codebase where an edition-specific rule may differ.

## Product baseline

- JACK is a Windows accounting application intended for offline-first use.
- Its shared configuration uses one host and authorized client computers on a private LAN, with centralized company data.
- End users should not need Node.js, ChatGPT, or a separately launched browser to run the packaged desktop edition.
- JACK supports multiple companies and role-controlled users. Established roles include Administrator, Bookkeeper, and Reviewer. User-count or reviewer-count limits are edition-specific; confirm them before changing enforcement.
- Existing records and complete backups must remain usable across an approved update unless the user explicitly approves an incompatible migration and recovery plan.
- Never expose JACK's LAN HTTP service directly to the public internet.

## Accounting invariants

- Every posted journal entry balances: total debits equal total credits.
- General Ledger balances reconcile to the Trial Balance for the same company and period.
- Income Statement and Balance Sheet amounts trace to the applicable ledger accounts and period filters.
- Opening balances, retained earnings or capital roll-forward, and cash-flow beginning and ending cash remain internally consistent.
- A/R, A/P, inventory, fixed assets, billing and collections, employee liquidation, and other subsidiary schedules reconcile to their control accounts when those modules are affected.
- VAT and withholding schedules trace to source transactions, tax classifications, TINs, dates, bases, rates, and posted accounts.
- Reversals, edits, deletions, or voids preserve auditability and do not leave orphaned subsidiary or tax records.
- Currency calculations use decimal-safe logic and the system's established rounding rules; never rely on binary floating-point where it can change posted money.

## Data and migration invariants

- Preserve company separation, primary keys, document numbers, account relationships, and audit metadata.
- Treat TINs, account codes, invoice numbers, reference numbers, and other identifiers as text when leading zeros or punctuation matter.
- Treat dates as local business dates unless the existing schema explicitly stores instants; guard against timezone or CSV date-offset errors.
- Make migrations repeatable or safely detectable, versioned, and recoverable.
- Compare record counts and monetary control totals before and after migration. Spot-check representative source records and reports.
- Validate backup and restore using an actual representative backup copy, never the user's only live file.

## Roles, audit, and concurrency

- Enforce permissions in application logic or the authoritative service layer, not only by hiding UI controls.
- Attribute create, edit, post, void, restore, import, and security-sensitive actions to the authenticated user when the audit model supports them.
- Protect against stale overwrites or ambiguous concurrent saves on LAN clients where the affected flow permits simultaneous work.
- Apply least privilege and require administrator authority for user management, restore, licensing, and other privileged configuration.

## Print and report invariants

- Every designated printable form and report must open a working print preview before final printing.
- User-facing output must not contain development labels such as "mockup" or "sample print" unless the user explicitly requests a watermark.
- Printed values, filters, company identity, trade name, TIN, period, page numbering, totals, signatures, headers, and footers must match the on-screen record and selected company.
- Test multi-page output, page breaks, repeated headers, legal or A4/Letter sizing as configured, long names, blank optional fields, and zero or negative amounts.
- Preserve the approved TBC/JACK branding rules for the active form; do not add or remove a logo across all documents based on one form-specific request.

## Licensing and distribution invariants

- Keep host-bound or signed licensing behavior compatible with the active edition.
- Never place a private signing key, owner-only activation secret, unrestricted source archive, or internal licensing dossier in a customer installer.
- Keep customer installers separate from owner/developer materials.
- Preserve third-party notices, ownership instruments, edition boundaries, and license terms required by the active distribution package.
- Hash only final frozen artifacts and record the algorithm, filename, size, and value.

## Version reconciliation

Historical JACK materials have used different product and edition labels, including client-evaluation V3.0.0, Desktop/User Manual V3.2.0, and Market Edition V1.3.x. Do not assume these describe one interchangeable build. Determine the active codebase and edition, then either reconcile every public version surface or document why distinct edition numbering is intentional.
