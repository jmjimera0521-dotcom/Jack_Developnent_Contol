---
name: jack-development-control
description: Review, diagnose, plan, implement, test, document, package, or release changes to JACK Accounting Software. Use whenever a request names JACK or works in its codebase, including bugs, features, database migrations, accounting calculations and reports, printable forms and preview, offline or LAN desktop operation, permissions, backup and restore, installers, licensing, versioning, or technical manuals. Do not use for accounting advice unrelated to JACK.
---

# JACK Development Control

Treat JACK as an accounting system with protected client data, not as a disposable prototype. Preserve the user's authorization boundary, diagnose before changing code, validate the affected accounting and operational controls, and leave a traceable development record.

## Choose the operating mode

Infer the narrowest authorized mode from the request:

- **Review or diagnose:** Inspect and explain only. Do not edit files, data, configuration, version labels, or installers. Treat phrases such as "review first," "tell me what happened," and "don't update yet" as read-only instructions.
- **Plan or specify:** Produce a design, impact assessment, or implementation plan without modifying the product unless the user also asks to build it.
- **Implement or fix:** Make only the requested change and the supporting edits required for correctness. Verify it safely.
- **Release or package:** Build release artifacts, update public version surfaces, checksums, manuals, or installers only when the user requests a release/package or clearly approves release preparation.

Do not broaden authorization from one mode to another. Ask only when an unresolved choice would materially change data, accounting behavior, compatibility, security, or release scope.

## Establish the working baseline

1. Locate the actual project and read applicable repository instructions.
2. Inspect existing changes and preserve unrelated user work.
3. Identify the active edition and version from code, manifests, the About screen, installer configuration, manuals, and filenames. If they disagree, report the conflict instead of selecting a version silently.
4. Identify the affected modules, files, database tables, reports, roles, forms, and integrations.
5. Before a risky implementation, confirm that a recoverable working copy or backup exists. Never experiment on the sole copy of client data.
6. Reproduce a reported defect when practical and record the evidence. Separate the observed symptom from the verified cause.

Read [references/jack-invariants.md](references/jack-invariants.md) before implementing, testing, migrating, packaging, or releasing. Use it during diagnosis when the issue may affect accounting data, reports, printing, LAN operation, permissions, backups, licensing, or compatibility.

## Control each change

1. Reuse an existing issue or change code when one is provided. Otherwise allocate a non-colliding code using [references/development-record.md](references/development-record.md).
2. State the requested outcome and acceptance criteria in concrete terms.
3. Trace the current behavior through the relevant UI, application logic, persistence layer, and report or print layer.
4. Identify the smallest complete fix. Avoid unrelated refactors unless they are necessary and disclosed.
5. For database changes, use a versioned migration, preserve existing records, define rollback or recovery, and test both upgraded and restored data.
6. Preserve established coding patterns, naming, encoding, and data types. Treat currency, dates, identifiers, TINs, account codes, and document numbers as precision-sensitive fields.
7. Keep source, signing keys, activation secrets, and owner-only licensing material out of customer builds and user-facing records.

## Validate by impact

Run the smallest sufficient test set plus every applicable control from `jack-invariants.md`.

- For transaction changes, test create, edit, post, unpost or reverse where supported, validation errors, permissions, audit trail, and report effects.
- For accounting logic, reconcile debits and credits, subsidiary records, ledgers, trial balance, financial statements, and affected tax schedules.
- For forms and reports, test on-screen values, print preview, printed or PDF layout, page breaks, headers, footers, totals, filters, and blank or multi-page cases.
- For migrations and backups, test a representative prior backup, record counts and control totals, rollback or restore, and reopening on the supported desktop/LAN setup.
- For LAN or permissions changes, test the host and an authorized client, concurrent or stale-save behavior where relevant, role restrictions, and audit attribution.
- For packaging, test a clean end-user installation without assuming Node.js, ChatGPT, or a separately launched browser.

Record exact commands and observable results. Never report a test as passed when it was not run. Identify environmental limitations and the remaining manual validation.

## Apply release discipline

Do not change the distributed version merely because development files changed. When a release is authorized:

- Use a patch version for a backward-compatible correction.
- Use a minor version for backward-compatible functionality.
- Use a major version for intentionally incompatible product, data, or deployment changes.
- Keep the application, About screen, package metadata, installer, filenames, user manual, technical specifications, release record, and checksums consistent.
- Preserve an unchanged deposit or archival build when the release is intended for licensing, copyright, or evidentiary records.
- Generate release hashes after the final artifacts are frozen; rebuilds invalidate earlier hashes.

## Produce the development record

After implementation, release work, or a material diagnosis, use [references/development-record.md](references/development-record.md). Lead with the outcome and include:

- the event code and status;
- the user's request, observed behavior, verified cause, and resolution;
- affected modules, files, functions, database objects, forms, and reports;
- exact code-level changes or focused excerpts when useful, without copying unrelated source;
- data, accounting, security, compatibility, printing, and version effects;
- tests performed, evidence, unresolved risks, and rollback or recovery instructions.

For a review-only request, make the record explicitly state **No changes made**.
